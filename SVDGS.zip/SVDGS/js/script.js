// ----------start javascript code----------
// start schedule flight
function arrDepFun() {
    var x = document.getElementById('arrDepart').value;
    if (x == 'Arrival' || x == 'arrival') {
        document.getElementById('BaggageLabel').style.display = "block";
        document.getElementById('BaggageDiv').style.display = "block";
    }
    else {
        document.getElementById('BaggageLabel').style.display = "none";
        document.getElementById('BaggageDiv').style.display = "none";
    }
}
// end update flight
function arrDepFunUpd() {
    var x = document.getElementById('arrDepartUpd').value;
    if (x == 'Arrival' || x == 'arrival') {
        document.getElementById('BaggageLabelUpd').style.display = "block";
        document.getElementById('BaggageDivUpd').style.display = "block";
    }
    else {
        document.getElementById('BaggageLabelUpd').style.display = "none";
        document.getElementById('BaggageDivUpd').style.display = "none";
    }
}
// end update flight
// ----------end javascript code----------
// ----------start jquery code----------
$(document).ready(function () {
    if (($(window).width() >= 768) & ($(window).width() < 991)) {
        // start my profile button
        $('#changeVal').removeClass('float-end').addClass('text-center');
        // end my profile button
    }
    if (($(window).width() <= 575)) {
        // start home page
        $('#homePage .float-start').removeClass('float-start').addClass('text-center');
        $('#homePage .float-end').removeClass('float-end').addClass('text-center');
        // end home page
        // start left section
        $('.leftAdmin li').removeClass('w-75 m-auto');
        // end left section
    }
    // start sweet alert on del icon
    $('#delMdl').on("click", function () {
        swal({
            title: "Are you sure?",
            text: "Once deleted, you will not be able to recover this record!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
            .then((willDelete) => {
                if (willDelete) {
                    swal("Poof! Your record has been deleted!", {
                        icon: "success",
                    });
                } else {
                    swal("Your record is safe!");
                }
            });
    });
    // end sweet alert on del icon
    // start number validation
    $('.numberonly').keypress(function (e) {
        var charCode = (e.which) ? e.which : event.keyCode
        if (String.fromCharCode(charCode).match(/[^0-9]/g))
            return false;
    });
    // end number validation
    // start left section
    $('#fltOpeEff').hide();
    $('#fltOpeClk').click(function () {
        $('#fltOpeEff').toggle();
    });
    $('#repEff').hide();
    $('#repClk').click(function () {
        $('#repEff').toggle();
    });
    $('#mngEff').hide();
    $('#mngClk').click(function () {
        $('#mngEff').toggle();
    });
    $('#roleEff').hide();
    $('#roleClk').click(function () {
        $('#roleEff').toggle();
    });
    // end left section
});
$(document).ready(function () {
    // start login captcha code
    var iNumber = Math.floor(Math.random() * 10000);
    $("#divGenerateRandomValues").css({ 'height': '50px' });
    $("#divGenerateRandomValues").html("<input id='txtNewInput'></input>");
    $("#txtNewInput").css({ 'background-image': 'url(../SVDGS/images/captcha.png)', 'font-family': 'Arial', 'font-style': 'bold', 'color': 'black', 'text-align': 'center', 'border-radius': '5px' });
    $("#txtNewInput").css({ 'width': '100%', 'color': 'black' });
    $("#txtNewInput").val(iNumber);
    $("#txtNewInput").prop('disabled', true);
    $("#btnGetCaptcha").click(function () {
        if ($("#textInput").val() != iNumber) {
            alert("Please fill captcha code");
        }
    });
    var wrongInput = function () {
        if ($("#textInput").val() != iNumber) {
            return true;
        }
        else {
            return false;
        }
    };
    $("#textInput").bind('input', function () {
        $("#btnGetCaptcha").prop('disabled', wrongInput);
    });
    // end login captcha code
});
// ----------end jquery code----------